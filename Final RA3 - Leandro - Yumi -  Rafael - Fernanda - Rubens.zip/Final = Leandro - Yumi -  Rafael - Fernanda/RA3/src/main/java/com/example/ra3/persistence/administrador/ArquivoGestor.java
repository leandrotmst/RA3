package com.example.ra3.persistence.administrador;

import com.example.ra3.domains.administrador.Gestor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ArquivoGestor {

    private static final String CAMINHO_ARQUIVO = "gestores.dat";

    public static void salvarLista(ArrayList<Gestor> gestores) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CAMINHO_ARQUIVO))) {
            oos.writeObject(gestores);
            System.out.println("Lista de gestores salva com " + gestores.size() + " itens.");
        } catch (IOException e) {
            System.err.println("Erro ao salvar gestores: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static ArrayList<Gestor> lerLista() {
        ArrayList<Gestor> lista = new ArrayList<>();
        File arquivo = new File(CAMINHO_ARQUIVO);
        if (arquivo.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(CAMINHO_ARQUIVO))) {
                lista = (ArrayList<Gestor>) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Erro ao ler gestores: " + e.getMessage());
            }
        }
        return lista;
    }

    public static boolean adicionarGestor(Gestor novo) {
        ArrayList<Gestor> gestores = lerLista();
        if (buscarPorEmail(novo.getEmail()) != null) {
            return false;
        }

        gestores.add(novo);
        salvarLista(gestores);
        System.out.println("Gestor adicionado: " + novo.getNome());
        return true;
    }

    public static Gestor buscarPorEmail(String email) {
        for (Gestor gestor : lerLista()) {
            if (gestor.getEmail().equalsIgnoreCase(email)) {
                return gestor;
            }
        }
        return null;
    }

    public static boolean atualizarGestor(Gestor antigo, Gestor atualizado) {
        ArrayList<Gestor> gestores = lerLista();
        for (Gestor gestor : gestores) {
            boolean outroRegistro = !gestor.getEmail().equalsIgnoreCase(antigo.getEmail());
            boolean mesmoEmail = gestor.getEmail().equalsIgnoreCase(atualizado.getEmail());
            if (outroRegistro && mesmoEmail) {
                return false;
            }
        }

        for (int i = 0; i < gestores.size(); i++) {
            if (gestores.get(i).getEmail().equalsIgnoreCase(antigo.getEmail())) {
                gestores.set(i, atualizado);
                salvarLista(gestores);
                return true;
            }
        }
        return false;
    }

    public static boolean verificarGestor(Gestor gestorParaVerificar) {
        gestorParaVerificar.setVerificado(true);
        return atualizarGestor(gestorParaVerificar, gestorParaVerificar);
    }

    public static void excluirGestor(Gestor gestorParaExcluir) {
        ArrayList<Gestor> restantes = new ArrayList<>();

        for (Gestor gestor : lerLista()) {
            if (!gestor.getEmail().equalsIgnoreCase(gestorParaExcluir.getEmail())) {
                restantes.add(gestor);
            }
        }

        salvarLista(restantes);
        System.out.println("Gestor excluido: " + gestorParaExcluir.getNome());
    }
}
